﻿using ColossalFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Journeys
{

    //[TargetType(typeof(PathVisualizer))]

    public class JourneyStepMgr
	{
        [NonSerialized]
        private Dictionary<ushort, JourneyStep> m_StepIndex;
        [NonSerialized]
        private Dictionary<string, ushort> m_HashToIdx;
        //public static JourneyStepMgr instance;
        private Stack<ushort> m_indexStack;
        private HashSet<ushort> m_targetSteps;


        public int StepCount => m_StepIndex.Count;

        private readonly object mgrLock = new object();

        public JourneyStepMgr()
        {
            m_StepIndex = new Dictionary<ushort, JourneyStep>();
            m_HashToIdx = new Dictionary<string, ushort>();
            m_indexStack = new Stack<ushort>();
            m_indexStack.Push(1);
            m_targetSteps = new HashSet<ushort>();
        }

        public void WipeSlate()
        {
            lock (mgrLock)
            {
                Debug.Log("JV: entered StepMgr.WipeSlate");
                lock (m_StepIndex)
                {
                    foreach (JourneyStep jStep in m_StepIndex.Values)
                        jStep.KillMeshes();
                    Debug.Log("JV: StepMge.WipeSlate has called all jstep.KillMeshes");
                    m_StepIndex.Clear();
                    m_HashToIdx.Clear();
                    m_indexStack.Clear();
                    m_indexStack.Push(1);
                    m_targetSteps.Clear();
                }
                Debug.Log("JV: finished StepMgr.WipeSlate");
            }
        }

        public void HideAllCims()
        {
            lock (mgrLock)
            {
                foreach (JourneyStep jstep in m_StepIndex.Values)
                {
                    jstep.HideAllCims(dolock: true);
                }
            }
        }


        public HashSet<ushort> GetLaneCims(ushort segmentID, byte lane)
        {
            HashSet<ushort> laneCims = new HashSet<ushort>();
            lock (mgrLock)
            {
                foreach (JourneyStep jStep in m_StepIndex.Values)
                {
                    List<ushort> outlist = jStep.HitSegmentLane(segmentID, lane);
                    if (outlist != null)
                    {
                        foreach (ushort cim in outlist)
                            laneCims.Add(cim);
                    }
                }
            }
            return laneCims;
        }

        public List<ushort> GetTargetSteps()
        {
            lock (mgrLock)
            {
                return m_targetSteps.ToList();
            }
        }

        public JourneyStep GetStep(ushort idx)
        {
            lock (mgrLock)
            {
                return m_StepIndex[idx];
            }
        }

        // Augment will either add a new JStep for a new step, for a given citizen journey, or increment an existing step
        // it returns the ushort index of the new (or pre-existing) step, which will not be zero
        public ushort Augment(List<Waypoint> route, ushort citizenID, LineColorPair lineColorPair, bool endJourney = false, bool show = true)
        {
            lock (mgrLock)
            {
                string hashname = Hashname(route[0], route[route.Count - 1]);
                if (m_HashToIdx.TryGetValue(hashname, out ushort uindex))
                {
                    //Debug.Log("Mgr Augment for existing step, cim " + citizenID + ", stepIndex " + uindex + ", hashname " + hashname);
                    m_StepIndex[uindex].AugmentStepData(citizenID, lineColorPair, show);
                    //Debug.Log("added to existing step " + uindex + ")");
                    return uindex;
                }
                else
                {
                    ushort newindex = GetNewIndex();
                    //Debug.Log("Mgr Augment for new step, cim " + citizenID + ", newIndex " + newindex + ", hashname " + hashname);
                    JourneyStep newStep = new JourneyStep(route, citizenID, lineColorPair, endJourney, show);
                    m_StepIndex.Add(newindex, newStep);
                    m_HashToIdx.Add(hashname, newindex);
                    //Debug.Log("added to new step " + newindex + ")");
                    // now add to targetSteps if appropriate
                    JourneyVisualizer theJV = Singleton<JourneyVisualizer>.instance;
                    foreach (Waypoint waypoint in route)
                    {
                        InstanceID newID = InstanceID.Empty;
                        newID.NetSegment = waypoint.Segment;
                        if (theJV.m_targets.Contains(newID))
                        {
                            m_targetSteps.Add(newindex);
                            break;
                        }
                    }
                    return newindex;
                }
            }
        }

        public void ReStep()
        {
            Dictionary<string, List<ushort>> linkedSteps = new Dictionary<string, List<ushort>>();
            string idxStr;
            foreach (KeyValuePair<ushort, JourneyStep> pair in m_StepIndex)
            {
                foreach (Waypoint wpoint in pair.Value.m_route)
                {
                    idxStr = wpoint.Segment + "+" + wpoint.Lane;
                if (linkedSteps.TryGetValue(idxStr, out List<ushort> stepIdxList)){
                    stepIdxList.Add(pair.Key);
                    linkedSteps[idxStr] = stepIdxList;
                }
                else
                {
                linkedSteps.Add(idxStr, new List<ushort> { pair.Key } );
                }
                }
            }
            foreach (KeyValuePair<string, List<ushort>> pair in linkedSteps)
            {
                idxStr = pair.Key;
                string[] idxStrSplit = idxStr.Split('\u002B');
                ushort idxSeg = (ushort)int.Parse(idxStrSplit[0]);
                ushort idxLane = (byte)int.Parse(idxStrSplit[1]);
                List<ushort> stepIdxList = pair.Value;
                if (stepIdxList.Count == 1)
                    continue;
                bool firstStep = true;
                List<JourneyStep> newSteps = new List<JourneyStep>();
                foreach (ushort stepIdx in stepIdxList)
                {
                    if (firstStep)
                    {
                        // this step may have already been split for a different overlap

                        // map this step to any replacing it (if none, use as is)

                        // for multi-segment Steps, split into 3 (potentially)
                        newSteps.Add(m_StepIndex[stepIdx]);
                        firstStep = false;
                    }
                    else
                    {
                        JourneyStep nextStep = m_StepIndex[stepIdx];
                        if (nextStep.StartStep.Segment != newSteps[0].StartStep.Segment)
                        {
                            // find the common segment, split both before and after, merge the middle like normal
                        }
                        if (nextStep.StartStep.Offset < newSteps[0].StartStep.Offset)
                        {

                        }
                    }
                    ushort limits = Starter stop

                }

            }
        }

        // Reduce removes a citizen from the indexed JStep.  If the citizen count is reduced to zero, the step is removed from the Mgr
        // if the indexed JStep does not exisit, does nothing (but error message to log)
        // check for the citizen not found in the JStep, error handling is in the jStep.ReduceStepData method (returns unchanged citizen count)
        public void Reduce(ushort stepIndex, ushort citizenID)
        {
            lock (mgrLock)
            {
                if (!m_StepIndex.TryGetValue(stepIndex, out JourneyStep jStep))
                {
                    Debug.LogError("JV Error: Fatal lookup error for stepIndex " + stepIndex + " in JourneyStepMgr.Reduce");
                    return;
                }
                string hashname = jStep.Hashname;
                //Debug.Log("Reduce for cim " + citizenID + ", stepIndex " + stepIndex + ", hashname " + hashname);
                if (jStep.ReduceStepData(citizenID) == 0)
                {
                    m_StepIndex.Remove(stepIndex);
                    m_HashToIdx.Remove(hashname);
                    m_indexStack.Push(stepIndex);
                }
            }
        }

        public void CalculateMeshes()
        {
            lock (mgrLock)
            {
                JourneyVisualizer theJV = Singleton<JourneyVisualizer>.instance;

                int denominator = theJV.m_journeys.Count;
                if (theJV.HeatOnlyAsSelected)
                    if (theJV.m_subsubselectedCims.Count > 0)
                        denominator = theJV.m_subsubselectedCims.Count;
                    else if (theJV.m_subselectedCims.Count > 0)
                        denominator = theJV.m_subselectedCims.Count;

                foreach (JourneyStep jStep in m_StepIndex.Values)
                {
                    if (jStep == null)
                        Debug.Log("JV Error: null jStep within CalculateMeshes loop");
                    jStep.SetRouteMeshes(denominator);
                }
                Debug.Log("JV: CalculateMeshes has called SetRouteMesh for all " + m_StepIndex.Count + " jSteps");
            }
        }

        public void ReheatMeshes()
        {
            lock (mgrLock)
            {
                JourneyVisualizer theJV = Singleton<JourneyVisualizer>.instance;

                int denominator = theJV.m_journeys.Count;
                if (theJV.HeatOnlyAsSelected)
                    if (theJV.m_subsubselectedCims.Count > 0)
                        denominator = theJV.m_subsubselectedCims.Count;
                    else if (theJV.m_subselectedCims.Count > 0)
                        denominator = theJV.m_subselectedCims.Count;

                foreach (JourneyStep jStep in m_StepIndex.Values)
                {
                    if (jStep == null)
                    {
                        Debug.Log("JV Error: null jStep within ReheatMeshes loop");
                        break;
                    }
                    jStep.SetRouteMeshes(denominator, forceReheat: true);
                }
            }
        }

        public void DrawTheMeshes(RenderManager.CameraInfo cameraInfo, int layerMask)
        {
            lock (mgrLock)
            {
                NetManager theNetManager = Singleton<NetManager>.instance;
                TerrainManager theTerrainManager = Singleton<TerrainManager>.instance;
                TransportManager theTransportManager = Singleton<TransportManager>.instance;
                Material xmaterial;
                Material xmaterial2;
                //bool xrequireSurfaceLine;
                int xlayer;
                //int xlayer2;
                TransportInfo transportInfo = Singleton<TransportManager>.instance.GetTransportInfo(TransportInfo.TransportType.Metro);
                if (transportInfo != null)
                {
                    xmaterial = transportInfo.m_lineMaterial2;
                    xmaterial2 = transportInfo.m_secondaryLineMaterial2;
                    // xrequireSurfaceLine = transportInfo.m_requireSurfaceLine;
                    xlayer = transportInfo.m_prefabDataLayer;
                    // xlayer2 = transportInfo.m_secondaryLayer;
                }
                else
                {
                    Debug.LogError("JV Error: Selected null material for rendering");
                    return;
                }
                Material material = (layerMask & 1 << xlayer) != 0 ? xmaterial : xmaterial2;
                //Debug.Log("JV: m_stepIndex.Count is " + m_StepIndex.Count);
                foreach (JourneyStep jStep in m_StepIndex.Values)
                {
                    if (jStep == null)
                        Debug.LogError("JV: null jStep in m_StepIndex dictionary");
                    jStep.DrawTheMeshes(cameraInfo, material);
                }
            }
        }

        public void DestroyAll()
        {
            lock (mgrLock)
            {
                foreach (JourneyStep jStep in m_StepIndex.Values)
                    jStep.KillMeshes();
                m_StepIndex = null;
                m_HashToIdx = null;
                m_indexStack = null;
            }
        }

        public string Hashname(Waypoint startpoint, Waypoint endpoint)
        {
            return startpoint.Segment + "+" + endpoint.Segment + "+" + startpoint.Offset + "+" + endpoint.Offset + "+" + startpoint.Lane + "+" + endpoint.Lane;
        }

        // to save an index for re-use, just Push it to m_indexStack
        private ushort GetNewIndex()
        {
            ushort nextindex = m_indexStack.Pop();
            if (m_indexStack.Count == 0)
                m_indexStack.Push((ushort)(nextindex + 1));
            return nextindex;
        }
    }
}
